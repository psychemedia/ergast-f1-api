#!/bin/sh
#
# Show information about container to standard output
#
#
# (c) 2017 nimmis <kjell.havneskold@gmail.com>
#

cat /etc/BUILDS/*

